# Quick & Spicy Nasi Goreng

**URL:** https://www.bbcgoodfood.com/recipes/quick-spicy-nasi-goreng


**Ingredients:**
• 30ml vegetable oil
• 1 small onion, finely sliced
• 2 garlic cloves, crushed
• 1 carrot, grated
• ½ small Chinese or Savoy cabbage, shredded
• 175g cooked brown rice
• 15ml fish sauce (optional)
• 15ml soy sauce
• 1 egg
• hot sriracha chilli sauce, to serve

**Method:**
1. Heat the oil in a wok over high heat. Add the onion and cook for 3-4 mins until softened and slightly caramelised. Add the garlic and stir for 1 min.
2. Toss in the carrot and cabbage, then cook for 1-2 mins. Add the rice and stir to warm through. Pour in the fish sauce, soy sauce and some seasoning. Make a well in the centre of the wok and crack in the egg. Fry until the white is nearly set.
3. Serve the rice in a large bowl, topped with the fried egg and drizzled with chilli sauce.