# Easy Beef Tacos

**URL:** https://www.tamingtwins.com/beef-tacos/


**Ingredients:**
• 30ml Sunflower oil
• 500g Beef mince (5% fat)
• 30ml Fajita seasoning
• 10g Garlic granules
• 30ml Tomato puree
• 400g Kidney beans (1 tin, drained and rinsed)
• 100ml Water
• Sea salt
• 8 Small tortilla wraps
• 100ml Sour cream (or yoghurt)
• 1/2 Iceberg lettuce (shredded)
• 2 Salad tomatoes (finely chopped)
• 60g Cheese (grated)

**Method:**
1. Heat 30ml sunflower oil in a sauté pan over medium heat. Add 500g beef mince and brown all over for about 5 minutes, breaking up with a spoon.
2. Add 30ml fajita seasoning, 10g garlic granules, 30ml tomato puree, 400g kidney beans, 100ml water, and a sprinkle of sea salt. Cook for a further 5-10 minutes until the beans are hot and the meat is well cooked.
3. Meanwhile, heat the tortillas according to the pack instructions (microwave, oven, gas flame, or toaster).
4. Pile in the fillings (or let everyone help themselves) and serve.