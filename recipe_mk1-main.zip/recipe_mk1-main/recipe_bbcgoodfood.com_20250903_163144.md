# Chicken & chorizo jambalaya

**URL:** https://www.bbcgoodfood.com/recipes/chicken-chorizo-jambalaya


**Ingredients:**
• 15ml olive oil
• 2 chicken breasts, chopped
• 1 onion, diced
• 1 red pepper, thinly sliced
• 2 garlic cloves, crushed
• 75g chorizo, sliced
• 15ml Cajun seasoning
• 250g long grain rice
• 400g can plum tomatoes
• 350ml chicken stock

**Method:**
1. Heat 15ml olive oil in a large frying pan with a lid over a medium-high heat and brown 2 chopped chicken breasts for 5-8 mins until golden.
2. Remove and set aside. Tip in the 1 diced onion and cook for 3-4 mins until soft.
3. Add 1 thinly sliced red pepper, 2 crushed garlic cloves, 75g sliced chorizo and 15ml Cajun seasoning, and cook for 5 mins more.
4. Stir the chicken back in with 250g long grain rice, add the 400g can of tomatoes and 350ml chicken stock. Cover and simmer over a medium heat for 20-25 mins until the rice is tender.